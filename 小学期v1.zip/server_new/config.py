# 数据库信息
db_info = {
    "host": "127.0.0.1",
    "port": 1433,
    "user": "secure_chat_user",
    "password": "SecureChat123!",
    "database": "secure_communication",
}

# 日志文件名
LOG_FILE = 'server.log'

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 50000
BUFFER_SIZE = 4096
