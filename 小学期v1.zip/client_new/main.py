import logging
import sys
import eventlet

# 导入 Flask 应用
from app import app, socketio

# 配置客户端应用的全局日志
logging.basicConfig(level=logging.INFO,  # 默认日志级别为 INFO
                    format='%(asctime)s - %(levelname)s - [%(name)s] %(message)s',  # 简化日志格式
                    handlers=[
                        logging.StreamHandler(sys.stdout)  # 确保日志输出到标准输出
                    ])

# 为核心模块设置合适的日志级别，专注于通信状态
logging.getLogger('utils.RSA').setLevel(logging.INFO) # 只显示重要RSA操作
logging.getLogger('utils.AES').setLevel(logging.INFO) # 只显示重要AES操作
logging.getLogger('p2p_manager').setLevel(logging.INFO) # 显示P2P连接状态
logging.getLogger('chat_client').setLevel(logging.INFO) # 显示消息发送和接收状态
logging.getLogger('flask_app').setLevel(logging.WARNING) # 减少不必要的Flask日志

# Flask-SocketIO 推荐通过 socketio.run(app) 来启动应用
if __name__ == "__main__":
    logger = logging.getLogger(__name__)  # 获取 main_client 模块的 logger 实例
    logger.info("客户端Web应用启动。")
    # 启动 Flask-SocketIO 应用，它会使用 eventlet 或 gevent 运行
    socketio.run(app, host='0.0.0.0', port=5000, debug=True, allow_unsafe_werkzeug=True)
    logger.info("客户端Web应用已停止。")
